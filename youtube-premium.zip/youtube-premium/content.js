(function () {
    'use strict';

    const api = youtubeHelperApi;
    if (!api) return console.error('Helper API not found. Likely incompatible script manager or extension settings.');

    api.debug.enabled = true;

    const STORAGE_KEY = 'YTHD_settings';
    const DEFAULT_SETTINGS = {
        targetResolution: 'hd2160',
    };

    const SVG_NS = 'http://www.w3.org/2000/svg';
    const CSS_STYLES = `
        #ythd-animation-wrapper {
            position: relative;
            overflow: hidden;
            transition: height 0.25s ease-in-out;
        }
        .ythd-slide-panel {
            position: absolute;
            width: 100%;
            top: 0;
            left: 0;
            transition: transform 0.25s ease-in-out;
        }
        #ythd-mobile-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.7); display: flex; align-items: center;
            justify-content: center; z-index: 9999; backdrop-filter: blur(4px);
        }
        .ythd-mobile-menu-box {
            background: #282828; color: white; padding: 16px;
            border-radius: 12px; min-width: 280px; max-width: 90%;
            font-family: "Roboto", "Arial", sans-serif;
        }
        .ythd-mobile-title { font-size: 1.2em; margin-bottom: 16px; font-weight: 500; }
        .ythd-menu-item { padding: 14px; cursor: pointer; border-radius: 8px; }
        .ythd-menu-item.active { font-weight: bold; background: rgba(255, 255, 255, 0.1); }
    `;

    const ICONS = {
        createPinIcon: () => {
            const svg = document.createElementNS(SVG_NS, 'svg');
            svg.setAttribute('viewBox', '0 0 24 24');
            svg.setAttribute('height', '24');
            svg.setAttribute('width', '24');
            const path = document.createElementNS(SVG_NS, 'path');
            path.setAttribute('d', 'M16,12V4H17V2H7V4H8V12L6,14V16H11.5V22H12.5V16H18V14L16,12Z');
            path.setAttribute('fill', 'currentColor');
            svg.appendChild(path);
            return svg;
        },
    };

    let userSettings = { ...DEFAULT_SETTINGS };

    function injectStyles() {
        const styleElement = document.createElement('style');
        styleElement.textContent = CSS_STYLES;
        document.head.appendChild(styleElement);
    }

    function setResolution() {
        api.setPlaybackResolution(userSettings.targetResolution);
    }

    function handlePlayerStateChange(playerState) {
        const playerElement = api.player.playerObject;
        if (!playerElement) return;

        if (playerState === 1 && !playerElement.hasAttribute('YTHD-resolution-set')) {
            playerElement.setAttribute('YTHD-resolution-set', 'true');
            setResolution();
        } else if (playerState === -1 && playerElement.hasAttribute('YTHD-resolution-set')) {
            playerElement.removeAttribute('YTHD-resolution-set');
        }
    }

    function processVideoLoad() {
        setResolution();
        const playerContainer = api.player.playerObject;
        if (playerContainer && !playerContainer.hasAttribute('YTHD-listener-added')) {
            playerContainer.addEventListener('onStateChange', handlePlayerStateChange);
            playerContainer.setAttribute('YTHD-listener-added', 'true');
        }
    }

    function createYTHDHeaderTrigger(titleText) {
        const header = document.createElement('div');
        header.id = 'ythd-header-trigger';
        header.className = 'ytp-panel-header';
        header.style.cursor = 'pointer';

        const title = document.createElement('div');
        title.className = 'ytp-panel-title';
        title.style.display = 'flex';
        title.style.justifyContent = 'space-between';
        title.style.width = '100%';
        title.style.alignItems = 'center';
        title.style.padding = '16px';

        const leftGroup = document.createElement('span');
        leftGroup.style.display = 'flex';
        leftGroup.style.alignItems = 'center';
        leftGroup.style.gap = '8px';
        leftGroup.append(ICONS.createPinIcon(), titleText);

        const rightGroup = document.createElement('span');
        rightGroup.id = 'ythd-header-label';
        rightGroup.textContent = `${api.POSSIBLE_RESOLUTIONS[userSettings.targetResolution].label} >`;

        title.append(leftGroup, rightGroup);
        header.appendChild(title);
        return header;
    }

    function setupQualityMenuNavigation(qualityPanel) {
        if (qualityPanel.querySelector('#ythd-animation-wrapper')) return;

        const nativeHeader = qualityPanel.querySelector('.ytp-panel-header');
        const nativeTitleText = nativeHeader?.querySelector('.ytp-panel-title')?.textContent.trim() || 'Quality';
        if (!nativeHeader) return;

        const ythdHeaderTrigger = createYTHDHeaderTrigger(nativeTitleText);
        nativeHeader.after(ythdHeaderTrigger);

        const animationWrapper = document.createElement('div');
        animationWrapper.id = 'ythd-animation-wrapper';

        const nativePanel = document.createElement('div');
        nativePanel.className = 'ythd-slide-panel';

        const customPanel = document.createElement('div');
        customPanel.className = 'ythd-slide-panel';
        customPanel.style.transform = 'translateX(100%)';

        Array.from(qualityPanel.children).forEach((child) => {
            nativePanel.appendChild(child);
        });

        animationWrapper.appendChild(nativePanel);
        animationWrapper.appendChild(customPanel);
        qualityPanel.appendChild(animationWrapper);

        const performSlideAnimation = (direction) => {
            const isForward = direction === 'forward';
            const currentPanel = isForward ? nativePanel : customPanel;
            const nextPanel = isForward ? customPanel : nativePanel;

            nextPanel.style.transition = 'none';
            nextPanel.style.transform = isForward ? 'translateX(100%)' : 'translateX(-100%)';

            void nextPanel.offsetHeight;

            animationWrapper.style.height = `${nextPanel.scrollHeight}px`;
            nextPanel.style.transition = 'transform 0.25s ease-in-out';
            currentPanel.style.transform = isForward ? 'translateX(-100%)' : 'translateX(100%)';
            nextPanel.style.transform = 'translateX(0)';
        };

        const switchToNativeMenu = () => {
            const restoredTriggerLabel = document.getElementById('ythd-header-label');
            if (restoredTriggerLabel) {
                restoredTriggerLabel.textContent = `${api.POSSIBLE_RESOLUTIONS[userSettings.targetResolution].label} >`;
            }
            performSlideAnimation('back');
        };

        const switchToYTHDMenu = () => {
            customPanel.replaceChildren();

            const backButton = document.createElement('button');
            backButton.className = 'ytp-panel-back-button ytp-button';
            backButton.style.padding = '0';

            const title = document.createElement('div');
            title.className = 'ytp-panel-title';
            title.style.display = 'flex';
            title.style.alignItems = 'center';
            title.style.gap = '8px';
            title.append(ICONS.createPinIcon(), nativeTitleText);

            const header = document.createElement('div');
            header.className = 'ytp-panel-header';
            header.append(backButton, title);

            const menu = document.createElement('div');
            menu.className = 'ytp-panel-menu';

            Object.entries(api.POSSIBLE_RESOLUTIONS).forEach(([key, value]) => {
                const menuItem = document.createElement('div');
                menuItem.className = 'ytp-menuitem';
                menuItem.setAttribute('role', 'menuitemradio');
                menuItem.setAttribute('aria-checked', (userSettings.targetResolution === key).toString());
                menuItem.dataset.resolutionKey = key;

                const labelDiv = document.createElement('div');
                labelDiv.className = 'ytp-menuitem-label';
                labelDiv.textContent = `${value.p}p ${value.label.includes('K') ? `(${value.label})` : ''}`.trim();
                menuItem.append(labelDiv);

                menuItem.addEventListener('click', async (event) => {
                    event.stopPropagation();
                    const newResolution = menuItem.dataset.resolutionKey;
                    if (userSettings.targetResolution === newResolution) return;

                    userSettings.targetResolution = newResolution;
                    await api.saveToStorage(STORAGE_KEY, userSettings);
                    setResolution();
                    switchToNativeMenu();
                });

                menu.appendChild(menuItem);
            });

            customPanel.append(header, menu);

            backButton.addEventListener('click', (event) => {
                event.stopPropagation();
                switchToNativeMenu();
            });

            performSlideAnimation('forward');
        };

        animationWrapper.style.height = `${nativePanel.scrollHeight}px`;

        ythdHeaderTrigger.addEventListener('click', (event) => {
            event.stopPropagation();
            switchToYTHDMenu();
        });
    }

    function startDesktopObserver() {
        const observer = new MutationObserver((mutations) => {
            let nodesAdded = false;
            for (const mutation of mutations) {
                if (mutation.addedNodes.length > 0) {
                    nodesAdded = true;
                    break;
                }
            }
            if (!nodesAdded) return;

            for (const mutation of mutations) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === 1 && node.classList.contains('ytp-panel')) {
                        if (node.querySelector('.ytp-menuitem[role="menuitemradio"]') && node.classList.contains('ytp-quality-menu')) {
                            setupQualityMenuNavigation(node);
                        }
                    }
                }
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    function showMobileQualityOverlay(closeNativeMenuCallback) {
        if (document.getElementById('ythd-mobile-overlay')) return;

        const overlay = document.createElement('div');
        overlay.id = 'ythd-mobile-overlay';

        const menuBox = document.createElement('div');
        menuBox.className = 'ythd-mobile-menu-box';

        const title = document.createElement('div');
        title.className = 'ythd-mobile-title';
        title.textContent = 'Set Quality Preference';
        menuBox.appendChild(title);

        Object.entries(api.POSSIBLE_RESOLUTIONS).forEach(([key, value]) => {
            const menuItem = document.createElement('div');
            menuItem.className = 'ythd-menu-item';
            if (userSettings.targetResolution === key) {
                menuItem.classList.add('active');
            }
            menuItem.textContent = `${value.p}p ${value.label.includes('K') ? `(${value.label})` : ''}`.trim();

            menuItem.onclick = async () => {
                userSettings.targetResolution = key;
                await api.saveToStorage(STORAGE_KEY, userSettings);
                setResolution();
                document.body.removeChild(overlay);
                if (closeNativeMenuCallback) closeNativeMenuCallback();
            };
            menuBox.appendChild(menuItem);
        });

        overlay.onclick = (event) => {
            if (event.target === overlay) {
                document.body.removeChild(overlay);
            }
        };

        overlay.appendChild(menuBox);
        document.body.appendChild(overlay);
    }

    function injectMobileTrigger(bottomSheetNode) {
        if (bottomSheetNode.querySelector('.ythd-mobile-trigger')) return;

        const templateItem = bottomSheetNode.querySelector('[role=menuitem], ytm-menu-service-item-renderer');
        if (!templateItem) return;

        const triggerItem = templateItem.cloneNode(true);
        triggerItem.classList.add('ythd-mobile-trigger');
        triggerItem.removeAttribute('aria-disabled');

        const icon = triggerItem.querySelector('yt-icon, c3-icon');
        const label = triggerItem.querySelector('.yt-formatted-string, .menu-service-item-text');

        if (icon) icon.replaceChildren(ICONS.createPinIcon());
        if (label) label.textContent = 'Set Quality Preference';

        triggerItem.onclick = (event) => {
            event.preventDefault();
            event.stopPropagation();

            const closeNativeMenu = () => document.querySelector('ytw-scrim')?.click();
            showMobileQualityOverlay(closeNativeMenu);
        };

        const parent = templateItem.parentElement;
        parent.insertBefore(triggerItem, parent.firstChild);
    }

    function initializeMobileEventListeners() {
        document.addEventListener(
            'click',
            (event) => {
                const settingsButton = event.target.closest(
                    '.player-settings-icon, [aria-label*="Settings"], .slim-video-metadata-actions button',
                );
                if (settingsButton) {
                    const observer = new MutationObserver((mutations, obs) => {
                        const bottomSheet = document.querySelector('bottom-sheet-container:not(:empty)');
                        if (bottomSheet) {
                            injectMobileTrigger(bottomSheet);
                            obs.disconnect();
                        }
                    });
                    observer.observe(document.body, { childList: true, subtree: true });
                }
            },
            true,
        );
    }

    async function initialize() {
        injectStyles();
        userSettings = await api.loadAndCleanFromStorage(STORAGE_KEY, DEFAULT_SETTINGS);
        await api.saveToStorage(STORAGE_KEY, userSettings);
        api.page.isMobile ? initializeMobileEventListeners() : startDesktopObserver();
        api.eventTarget.addEventListener('yt-helper-api-ready', processVideoLoad);
    }

    initialize();
})();

(function() {var css = [
        "  #logo-container .logo,",
		"	.footer-logo-icon,",
		"	#logo-icon,",
		"	#logo-icon-container",
		"  {",
		"    width: 98px !important;",
		"    margin-left: 5px;",
		"    margin-right: 5px;",
		"    content: url(\"data:image/svg+xml,%3Csvg xmlns:dc=\'http://purl.org/dc/elements/1.1/\' xmlns:cc=\'http://creativecommons.org/ns%23\' xmlns:rdf=\'http://www.w3.org/1999/02/22-rdf-syntax-ns%23\' xmlns:svg=\'http://www.w3.org/2000/svg\' xmlns=\'http://www.w3.org/2000/svg\' id=\'SVGRoot\' version=\'1.1\' viewBox=\'0 0 846 174\' height=\'80px\' width=\'391px\'%3E%3Cdefs id=\'defs855\'%3E%3Cstyle id=\'style2\' /%3E%3C/defs%3E%3Cmetadata id=\'metadata858\'%3E%3Crdf:RDF%3E%3Ccc:Work rdf:about=\'\'%3E%3Cdc:format%3Eimage/svg+xml%3C/dc:format%3E%3Cdc:type rdf:resource=\'http://purl.org/dc/dcmitype/StillImage\' /%3E%3Cdc:title%3E%3C/dc:title%3E%3C/cc:Work%3E%3C/rdf:RDF%3E%3C/metadata%3E%3Cg id=\'layer1\'%3E%3Cg transform=\'translate(0,0.36)\' data-name=\'Layer 2\' id=\'Layer_2\'%3E%3Cg data-name=\'Layer 1\' id=\'Layer_1-2\'%3E%3Cpath style=\'fill:%23ff0000\' id=\'path6\' d=\'M 242.88,27.11 A 31.07,31.07 0 0 0 220.95,5.18 C 201.6,0 124,0 124,0 124,0 46.46,0 27.11,5.18 A 31.07,31.07 0 0 0 5.18,27.11 C 0,46.46 0,86.82 0,86.82 c 0,0 0,40.36 5.18,59.71 a 31.07,31.07 0 0 0 21.93,21.93 c 19.35,5.18 96.92,5.18 96.92,5.18 0,0 77.57,0 96.92,-5.18 a 31.07,31.07 0 0 0 21.93,-21.93 c 5.18,-19.35 5.18,-59.71 5.18,-59.71 0,0 0,-40.36 -5.18,-59.71 z\' /%3E%3Cpath style=\'fill:%23ffffff\' id=\'path8\' d=\'M 99.22,124.03 163.67,86.82 99.22,49.61 Z\' /%3E%3Cpath style=\'fill:%23282828\' id=\'path10\' d=\'m 358.29,55.1 v 6 c 0,30 -13.3,47.53 -42.39,47.53 h -4.43 v 52.5 H 287.71 V 12.36 H 318 c 27.7,0 40.29,11.71 40.29,42.74 z m -25,2.13 c 0,-21.64 -3.9,-26.78 -17.38,-26.78 h -4.43 v 60.48 h 4.08 c 12.77,0 17.74,-9.22 17.74,-29.26 z m 81.22,-6.56 -1.24,28.2 c -10.11,-2.13 -18.45,-0.53 -22.17,6 v 76.26 H 367.52 V 52.44 h 18.8 L 388.45,76 h 0.89 c 2.48,-17.2 10.46,-25.89 20.75,-25.89 a 22.84,22.84 0 0 1 4.42,0.56 z M 441.64,115 v 5.5 c 0,19.16 1.06,25.72 9.22,25.72 7.8,0 9.58,-6 9.75,-18.44 l 21.1,1.24 c 1.6,23.41 -10.64,33.87 -31.39,33.87 -25.18,0 -32.63,-16.49 -32.63,-46.46 v -19 c 0,-31.57 8.34,-47 33.34,-47 25.18,0 31.57,13.12 31.57,45.93 V 115 Z m 0,-22.35 v 7.8 h 17.91 V 92.7 c 0,-20 -1.42,-25.72 -9,-25.72 -7.58,0 -8.91,5.86 -8.91,25.72 z M 604.45,79 v 82.11 H 580 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8.16,2.48 -10.82,7.09 a 35.59,35.59 0 0 1 0.18,4.43 v 82.11 H 537.24 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8,2.48 -10.64,6.92 v 86.72 H 494.5 V 52.44 h 19.33 L 516,66.28 h 0.35 c 5.5,-10.46 14.37,-16.14 24.83,-16.14 10.29,0 16.14,5.14 18.8,14.37 5.68,-9.4 14.19,-14.37 23.94,-14.37 14.86,0 20.53,10.64 20.53,28.86 z m 12.24,-54.4 c 0,-11.71 4.26,-15.07 13.3,-15.07 9.22,0 13.3,3.9 13.3,15.07 0,12.06 -4.08,15.08 -13.3,15.08 -9.04,-0.01 -13.3,-3.02 -13.3,-15.08 z m 1.42,27.84 h 23.41 v 108.72 h -23.41 z m 103.39,0 v 108.72 h -19.15 l -2.13,-13.3 h -0.53 c -5.5,10.64 -13.48,15.07 -23.41,15.07 -14.54,0 -21.11,-9.22 -21.11,-29.26 V 52.44 h 24.47 v 79.81 c 0,9.58 2,13.48 6.92,13.48 A 12.09,12.09 0 0 0 697,138.81 V 52.44 Z M 845.64,79 v 82.11 H 821.17 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8.16,2.48 -10.82,7.09 A 35.59,35.59 0 0 1 802.9,79 v 82.11 H 778.43 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8,2.48 -10.64,6.92 v 86.72 H 735.69 V 52.44 H 755 l 2.13,13.83 h 0.35 c 5.5,-10.46 14.37,-16.14 24.83,-16.14 10.29,0 16.14,5.14 18.8,14.37 5.68,-9.4 14.19,-14.37 23.94,-14.37 14.95,0.01 20.59,10.65 20.59,28.87 z\' /%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E%0A\") !important;",
		"  }",
		"",
		"  html[dark] #logo-icon,",
		"	html[dark] #logo-icon-container",
		"  {",
		"    width: 98px !important;",
		"    content: url(\"data:image/svg+xml,%3Csvg xmlns:dc=\'http://purl.org/dc/elements/1.1/\' xmlns:cc=\'http://creativecommons.org/ns%23\' xmlns:rdf=\'http://www.w3.org/1999/02/22-rdf-syntax-ns%23\' xmlns:svg=\'http://www.w3.org/2000/svg\' xmlns=\'http://www.w3.org/2000/svg\' id=\'SVGRoot\' version=\'1.1\' viewBox=\'0 0 846 174\' height=\'24px\' width=\'98px\'%3E%3Cdefs id=\'defs855\'%3E%3Cstyle id=\'style2\' /%3E%3C/defs%3E%3Cmetadata id=\'metadata858\'%3E%3Crdf:RDF%3E%3Ccc:Work rdf:about=\'\'%3E%3Cdc:format%3Eimage/svg+xml%3C/dc:format%3E%3Cdc:type rdf:resource=\'http://purl.org/dc/dcmitype/StillImage\' /%3E%3Cdc:title%3E%3C/dc:title%3E%3C/cc:Work%3E%3C/rdf:RDF%3E%3C/metadata%3E%3Cg id=\'layer1\'%3E%3Cg transform=\'translate(0,0.36)\' data-name=\'Layer 2\' id=\'Layer_2\'%3E%3Cg data-name=\'Layer 1\' id=\'Layer_1-2\'%3E%3Cpath style=\'fill:%23ff0000\' id=\'path6\' d=\'M 242.88,27.11 A 31.07,31.07 0 0 0 220.95,5.18 C 201.6,0 124,0 124,0 124,0 46.46,0 27.11,5.18 A 31.07,31.07 0 0 0 5.18,27.11 C 0,46.46 0,86.82 0,86.82 c 0,0 0,40.36 5.18,59.71 a 31.07,31.07 0 0 0 21.93,21.93 c 19.35,5.18 96.92,5.18 96.92,5.18 0,0 77.57,0 96.92,-5.18 a 31.07,31.07 0 0 0 21.93,-21.93 c 5.18,-19.35 5.18,-59.71 5.18,-59.71 0,0 0,-40.36 -5.18,-59.71 z\' /%3E%3Cpath style=\'fill:%23ffffff\' id=\'path8\' d=\'M 99.22,124.03 163.67,86.82 99.22,49.61 Z\' /%3E%3Cpath style=\'fill:%23ffffff\' id=\'path10\' d=\'m 358.29,55.1 v 6 c 0,30 -13.3,47.53 -42.39,47.53 h -4.43 v 52.5 H 287.71 V 12.36 H 318 c 27.7,0 40.29,11.71 40.29,42.74 z m -25,2.13 c 0,-21.64 -3.9,-26.78 -17.38,-26.78 h -4.43 v 60.48 h 4.08 c 12.77,0 17.74,-9.22 17.74,-29.26 z m 81.22,-6.56 -1.24,28.2 c -10.11,-2.13 -18.45,-0.53 -22.17,6 v 76.26 H 367.52 V 52.44 h 18.8 L 388.45,76 h 0.89 c 2.48,-17.2 10.46,-25.89 20.75,-25.89 a 22.84,22.84 0 0 1 4.42,0.56 z M 441.64,115 v 5.5 c 0,19.16 1.06,25.72 9.22,25.72 7.8,0 9.58,-6 9.75,-18.44 l 21.1,1.24 c 1.6,23.41 -10.64,33.87 -31.39,33.87 -25.18,0 -32.63,-16.49 -32.63,-46.46 v -19 c 0,-31.57 8.34,-47 33.34,-47 25.18,0 31.57,13.12 31.57,45.93 V 115 Z m 0,-22.35 v 7.8 h 17.91 V 92.7 c 0,-20 -1.42,-25.72 -9,-25.72 -7.58,0 -8.91,5.86 -8.91,25.72 z M 604.45,79 v 82.11 H 580 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8.16,2.48 -10.82,7.09 a 35.59,35.59 0 0 1 0.18,4.43 v 82.11 H 537.24 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8,2.48 -10.64,6.92 v 86.72 H 494.5 V 52.44 h 19.33 L 516,66.28 h 0.35 c 5.5,-10.46 14.37,-16.14 24.83,-16.14 10.29,0 16.14,5.14 18.8,14.37 5.68,-9.4 14.19,-14.37 23.94,-14.37 14.86,0 20.53,10.64 20.53,28.86 z m 12.24,-54.4 c 0,-11.71 4.26,-15.07 13.3,-15.07 9.22,0 13.3,3.9 13.3,15.07 0,12.06 -4.08,15.08 -13.3,15.08 -9.04,-0.01 -13.3,-3.02 -13.3,-15.08 z m 1.42,27.84 h 23.41 v 108.72 h -23.41 z m 103.39,0 v 108.72 h -19.15 l -2.13,-13.3 h -0.53 c -5.5,10.64 -13.48,15.07 -23.41,15.07 -14.54,0 -21.11,-9.22 -21.11,-29.26 V 52.44 h 24.47 v 79.81 c 0,9.58 2,13.48 6.92,13.48 A 12.09,12.09 0 0 0 697,138.81 V 52.44 Z M 845.64,79 v 82.11 H 821.17 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8.16,2.48 -10.82,7.09 A 35.59,35.59 0 0 1 802.9,79 v 82.11 H 778.43 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8,2.48 -10.64,6.92 v 86.72 H 735.69 V 52.44 H 755 l 2.13,13.83 h 0.35 c 5.5,-10.46 14.37,-16.14 24.83,-16.14 10.29,0 16.14,5.14 18.8,14.37 5.68,-9.4 14.19,-14.37 23.94,-14.37 14.95,0.01 20.59,10.65 20.59,28.87 z\' /%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E%0A\") !important;",
		"  }",
		"",
	].join("\n");
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	}
}
)();
(function() {
    `use strict`;
 
    let video;
    //界面广告选择器
    const cssSelectorArr = [
        `#masthead-ad`,//首页顶部横幅广告.
        `ytd-rich-item-renderer.style-scope.ytd-rich-grid-row #content:has(.ytd-display-ad-renderer)`,//首页视频排版广告.
        `.video-ads.ytp-ad-module`,//播放器底部广告.
        `tp-yt-paper-dialog:has(yt-mealbar-promo-renderer)`,//播放页会员促销广告.
        `ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"]`,//播放页右上方推荐广告.
        `#related #player-ads`,//播放页评论区右侧推广广告.
        `#related ytd-ad-slot-renderer`,//播放页评论区右侧视频排版广告.
        `ytd-ad-slot-renderer`,//搜索页广告.
        `yt-mealbar-promo-renderer`,//播放页会员推荐广告.
        `ytd-popup-container:has(a[href="/premium"])`,//会员拦截广告
        `ad-slot-renderer`,//M播放页第三方推荐广告
        `ytm-companion-ad-renderer`,//M可跳过的视频广告链接处
    ];
    window.dev=false;//开发使用
 
    /**
    * 将标准时间格式化
    * @param {Date} time 标准时间
    * @param {String} format 格式
    * @return {String}
    */
    function moment(time) {
        // 获取年⽉⽇时分秒
        let y = time.getFullYear()
        let m = (time.getMonth() + 1).toString().padStart(2, `0`)
        let d = time.getDate().toString().padStart(2, `0`)
        let h = time.getHours().toString().padStart(2, `0`)
        let min = time.getMinutes().toString().padStart(2, `0`)
        let s = time.getSeconds().toString().padStart(2, `0`)
        return `${y}-${m}-${d} ${h}:${min}:${s}`
    }
 
    /**
    * 输出信息
    * @param {String} msg 信息
    * @return {undefined}
    */
    function log(msg) {
        if(!window.dev){
            return false;
        }
        console.log(window.location.href);
        console.log(`${moment(new Date())}  ${msg}`);
    }
 
    /**
    * 设置运行标志
    * @param {String} name
    * @return {undefined}
    */
    function setRunFlag(name){
        let style = document.createElement(`style`);
        style.id = name;
        (document.head || document.body).appendChild(style);//将节点附加到HTML.
    }
 
    /**
    * 获取运行标志
    * @param {String} name
    * @return {undefined|Element}
    */
    function getRunFlag(name){
        return document.getElementById(name);
    }
 
    /**
    * 检查是否设置了运行标志
    * @param {String} name
    * @return {Boolean}
    */
    function checkRunFlag(name){
        if(getRunFlag(name)){
            return true;
        }else{
            setRunFlag(name)
            return false;
        }
    }
 
    /**
    * 生成去除广告的css元素style并附加到HTML节点上
    * @param {String} styles 样式文本
    * @return {undefined}
    */
    function generateRemoveADHTMLElement(id) {
        //如果已经设置过,退出.
        if (checkRunFlag(id)) {
            log(`屏蔽页面广告节点已生成`);
            return false
        }
 
        //设置移除广告样式.
        let style = document.createElement(`style`);//创建style元素.
        (document.head || document.body).appendChild(style);//将节点附加到HTML.
        style.appendChild(document.createTextNode(generateRemoveADCssText(cssSelectorArr)));//附加样式节点到元素节点.
        log(`生成屏蔽页面广告节点成功`);
    }
 
    /**
    * 生成去除广告的css文本
    * @param {Array} cssSelectorArr 待设置css选择器数组
    * @return {String}
    */
    function generateRemoveADCssText(cssSelectorArr){
        cssSelectorArr.forEach((selector,index)=>{
            cssSelectorArr[index]=`${selector}{display:none!important}`;//遍历并设置样式.
        });
        return cssSelectorArr.join(` `);//拼接成字符串.
    }
 
    /**
    * 触摸事件
    * @return {undefined}
    */
    function nativeTouch(){
        // 创建 Touch 对象
        let touch = new Touch({
            identifier: Date.now(),
            target: this,
            clientX: 12,
            clientY: 34,
            radiusX: 56,
            radiusY: 78,
            rotationAngle: 0,
            force: 1
        });
 
        // 创建 TouchEvent 对象
        let touchStartEvent = new TouchEvent(`touchstart`, {
            bubbles: true,
            cancelable: true,
            view: window,
            touches: [touch],
            targetTouches: [touch],
            changedTouches: [touch]
        });
 
        // 分派 touchstart 事件到目标元素
        this.dispatchEvent(touchStartEvent);
 
        // 创建 TouchEvent 对象
        let touchEndEvent = new TouchEvent(`touchend`, {
            bubbles: true,
            cancelable: true,
            view: window,
            touches: [],
            targetTouches: [],
            changedTouches: [touch]
        });
 
        // 分派 touchend 事件到目标元素
        this.dispatchEvent(touchEndEvent);
    }
 
 
    /**
    * 获取dom
    * @return {undefined}
    */
    function getVideoDom(){
        video = document.querySelector(`.ad-showing video`) || document.querySelector(`video`);
    }
 
 
    /**
    * 自动播放
    * @return {undefined}
    */
    function playAfterAd(){
        if(video.paused && video.currentTime<1){
            video.play();
            log(`自动播放视频`);
        }
    }
 
 
    /**
    * 移除YT拦截广告拦截弹窗并且关闭关闭遮罩层
    * @return {undefined}
    */
    function closeOverlay(){
        //移除YT拦截广告拦截弹窗
        const premiumContainers = [...document.querySelectorAll(`ytd-popup-container`)];
        const matchingContainers = premiumContainers.filter(container => container.querySelector(`a[href="/premium"]`));
 
        if(matchingContainers.length>0){
            matchingContainers.forEach(container => container.remove());
            log(`移除YT拦截器`);
        }
 
        // 获取所有具有指定标签的元素
        const backdrops = document.querySelectorAll(`tp-yt-iron-overlay-backdrop`);
        // 查找具有特定样式的元素
        const targetBackdrop = Array.from(backdrops).find(
            (backdrop) => backdrop.style.zIndex === `2201`
        );
        // 如果找到该元素，清空其类并移除 open 属性
        if (targetBackdrop) {
            targetBackdrop.className = ``; // 清空所有类
            targetBackdrop.removeAttribute(`opened`); // 移除 open 属性
            log(`关闭遮罩层`);
        }
    }
 
 
    /**
    * 跳过广告
    * @return {undefined}
    */
    function skipAd(mutationsList, observer) {
        const skipButton = document.querySelector(`.ytp-ad-skip-button`) || document.querySelector(`.ytp-skip-ad-button`) || document.querySelector(`.ytp-ad-skip-button-modern`);
        const shortAdMsg = document.querySelector(`.video-ads.ytp-ad-module .ytp-ad-player-overlay`) || document.querySelector(`.ytp-ad-button-icon`);
 
        if((skipButton || shortAdMsg) && window.location.href.indexOf(`https://m.youtube.com/`) === -1){ //移动端静音有bug
            video.muted = true;
        }
 
        if(skipButton){
            const delayTime = 0.5;
            setTimeout(skipAd,delayTime*1000);//如果click和call没有跳过更改，直接更改广告时间
            if(video.currentTime>delayTime){
                video.currentTime = video.duration;//强制
                log(`特殊账号跳过按钮广告`);
                return;
            }
            skipButton.click();//PC
            nativeTouch.call(skipButton);//Phone
            log(`按钮跳过广告`);
        }else if(shortAdMsg){
            video.currentTime = video.duration;//强制
            log(`强制结束了该广告`);
        }
 
    }
 
    /**
    * 去除播放中的广告
    * @return {undefined}
    */
    function removePlayerAD(id){
        //如果已经在运行,退出.
        if (checkRunFlag(id)) {
            log(`去除播放中的广告功能已在运行`);
            return false
        }
 
        //监听视频中的广告并处理
        const targetNode = document.body;//直接监听body变动
        const config = {childList: true, subtree: true };// 监听目标节点本身与子树下节点的变动
        const observer = new MutationObserver(()=>{getVideoDom();closeOverlay();skipAd();playAfterAd();});//处理视频广告相关
        observer.observe(targetNode, config);// 以上述配置开始观察广告节点
        log(`运行去除播放中的广告功能成功`);
    }
 
    /**
    * main函数
    */
    function main(){
        generateRemoveADHTMLElement(`removeADHTMLElement`);//移除界面中的广告.
        removePlayerAD(`removePlayerAD`);//移除播放中的广告.
    }
 
    if (document.readyState === `loading`) {
        document.addEventListener(`DOMContentLoaded`, main);// 此时加载尚未完成
        log(`YouTube去广告脚本即将调用:`);
    } else {
        main();// 此时`DOMContentLoaded` 已经被触发
        log(`YouTube去广告脚本快速调用:`);
    }
 
    let resumeVideo = () => {
        const videoelem = document.body.querySelector('video.html5-main-video')
        if (videoelem && videoelem.paused) {
             console.log('resume video')
             videoelem.play()
        }
    }
 
    let removePop = node => {
        const elpopup = node.querySelector('.ytd-popup-container > .ytd-popup-container > .ytd-enforcement-message-view-model')
 
        if (elpopup) {
            elpopup.parentNode.remove()
            console.log('remove popup', elpopup)
            const bdelems = document
                .getElementsByTagName('tp-yt-iron-overlay-backdrop')
            for (var x = (bdelems || []).length; x--;)
                bdelems[x].remove()
            resumeVideo()
        }
 
        if (node.tagName.toLowerCase() === 'tp-yt-iron-overlay-backdrop') {
            node.remove()
            resumeVideo()
            console.log('remove backdrop', node)
        }
    }
 
    let obs = new MutationObserver(mutations => mutations.forEach(mutation => {
        if (mutation.type === 'childList') {
            Array.from(mutation.addedNodes)
                .filter(node => node.nodeType === 1)
                .map(node => removePop(node))
        }
    }))
 
    // have the observer observe foo for changes in children
    obs.observe(document.body, {
        childList: true,
        subtree: true
    })
})();