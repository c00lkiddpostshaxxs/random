console.log("YouTube HD Premium Combined loaded");

function applyPremiumLogo() {

    const logo = document.querySelector("ytd-topbar-logo-renderer");

    if (!logo) return;

    const text = logo.querySelector("#text");

    if (!text) return;

    text.innerHTML = `
        <span style="
            font-weight:700;
            color:#FF0033;
        ">
        Premium
        </span>
    `;
}

/* run immediately */
applyPremiumLogo();

/* YouTube SPA navigation */
document.addEventListener("yt-navigate-finish", () => {
    setTimeout(applyPremiumLogo, 700);
});
